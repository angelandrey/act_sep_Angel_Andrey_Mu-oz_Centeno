# grados-F-a-C-
print(" ")
print("Angel Andrey Muñoz Centeno 3W")
print(" ")
# Solicitar al usuario la temperatura en Fahrenheit
fahrenheit = float(input("Ingrese la temperatura en grados Fahrenheit: "))

# Calcular el equivalente en grados Celsius
celsius = (5/9) * (fahrenheit - 32)

# Mostrar el resultado
print(f"La temperatura en grados Celsius es: {celsius:.2f}°C")
![image](https://github.com/user-attachments/assets/b8ee6915-0f58-45e2-bbdf-4979e11ded5d)
