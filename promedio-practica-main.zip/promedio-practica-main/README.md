# promedio-practica
print(" ")
print("Angel Andrey Muñoz Centeno 3W")
print(" ")
# Solicitar al usuario ingresar tres números
num1 = float(input("Ingrese el primer número: "))
num2 = float(input("Ingrese el segundo número: "))
num3 = float(input("Ingrese el tercer número: "))

# Calcular el promedio
promedio = (num1 + num2 + num3) / 3

# Mostrar el resultado
print(f"El promedio de los tres números es: {promedio:.2f}")

![image](https://github.com/user-attachments/assets/64d37461-816d-4f5c-b6bc-3bf59bce9df4)
